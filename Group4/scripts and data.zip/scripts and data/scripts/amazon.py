import twitter
import csv
import HTMLParser
import pymongo
from numpy import *
import re

api = twitter.Api(
consumer_key='JeCdbwdDuVpPzwRh4aLvJYKj2',
consumer_secret='6cEXsnpvcaonemZz9KJG059E2yOXWLFCnQax0t1rdq9FRcPwIq',
access_token_key='2313880676-QhO7bT3tojJfurFZJjjpJqAOXtj7fdB6gJPLzgk',
access_token_secret='XVTtZu0sYtd7WqBemaDf8bOXSEhUkqfUEwJDXv1MoRFJf'
)

html_parser = HTMLParser.HTMLParser()
search4 = api.GetSearch(term=('Minions'),lang='en', count=200, result_type='recent')

file = open('/Users/insignia/Desktop/Big_Data_Analytics/alchemy/out.txt', 'w')

for tweet4 in search4:
    t4 = html_parser.unescape(tweet4.text)
    text4 = re.sub(r"http\S+", "", t4)
    encode4 = text4.encode('ascii','ignore').decode('ascii')
    twe4 = " ".join(re.findall('[A-Z][^A-Z]*', encode4))
    cleaned4 = ' '.join(re.sub("(@[A-Za-z0-9]+)|([^0-9A-Za-z \t])","",twe4).split())
    file.write('id: '+str(tweet4.id)+', '+'text: '+cleaned4+'\n')
file.close()
