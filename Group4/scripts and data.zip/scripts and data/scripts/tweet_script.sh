# bin/bash

python recipe.py 'SouthPaw' 100

cat test.json >> data.json

python recipe.py 'Minions' 100

cat test.json >> data.json

python recipe.py 'FantasticFour' 100

cat test.json >> data.json

python recipe.py 'RogueNation' 100

cat test.json >> data.json

python recipe.py 'InsideOut' 100

cat test.json >> data.json
