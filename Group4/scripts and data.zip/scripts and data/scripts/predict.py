from pyspark.sql import *
import os
import requests
from pyspark.mllib.classification import SVMWithSGD, SVMModel, LogisticRegressionWithLBFGS
from pyspark.mllib.regression import LabeledPoint, LassoWithSGD
from pyspark.mllib.regression import LinearRegressionWithSGD, RidgeRegressionWithSGD
from pyspark import SparkContext

sparkHome = os.environ.get('SPARK_HOME')
sc = SparkContext(appName="Classification")

#defining a function to split values
def parsePoint(line):
    values = [float(x) for x in line.split(',')]
    return LabeledPoint(values[11], values[1:10])


#reading csv file into rdd
rdd_train = sc.textFile("/train.csv")
rdd_test = sc.textFile("/test.csv")

parsedData_train = rdd_train.map(parsePoint)
parsedData_test = rdd_test.map(parsePoint)

#run LinearRegression
model = LinearRegressionWithSGD.train(parsedData_train,100,0.00000001)

#Evaluate the model on training data
valuesAndPreds_train = parsedData_train.map(lambda p: (p.label, model.predict(p.features)))
MSE = valuesAndPreds_train.map(lambda (v, p): (v - p)**2).reduce(lambda x, y: x + y) / valuesAndPreds_train.count()
print("Training Mean Squared Error for Linear Regression = " + str(MSE))

#Evaluate the model on testing data
valuesAndPreds_test = parsedData_test.map(lambda p: (p.label, model.predict(p.features)))
MSE = valuesAndPreds_test.map(lambda (v, p): (v - p)**2).reduce(lambda x, y: x + y) / valuesAndPreds_test.count()
print("Testing Mean Squared Error for Linear Regression = " + str(MSE))