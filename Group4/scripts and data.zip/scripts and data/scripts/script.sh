# bin/bash

sudo wget https://s3.amazonaws.com/bigdataanalyticscourse/Json_input_train/data.json

python /relevancescore.py