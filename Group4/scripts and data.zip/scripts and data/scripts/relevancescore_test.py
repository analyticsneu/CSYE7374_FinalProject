import json
import pandas as pd
import numpy as np

with open('final3.json', 'r') as f1:
    data_test = f1.readlines()
    data_test = map(lambda x: x.encode('utf-8').rstrip(), data_test)
    data_json_str = "[" + ','.join(data_test) + "]"
    df_test = pd.read_json(data_json_str)

i=0
j=0
k=0
l=0
m=0
n=0

df_test['Rel_score_rt'] = np.NaN
df_test['Rel_score_fol'] = np.NaN
df_test['Rel_score_fav'] = np.NaN
df_test['Rel_score_ver'] = np.NaN
df_test['verified_numerical'] = np.NaN
df_test['sentiment_numerical'] = np.NaN


def relevanceScore_rt(frame):
    rel_rt = 0.3
    if frame <= 50:
        rel_rt = (rel_rt/3)
    elif (frame > 50) and (frame <= 500):
        rel_rt = (((rel_rt)*2)/3)
    else:
        rel_rt
    return rel_rt

def relevanceScore_fol(frame):
    rel_fol = 0.3
    if frame <= 500:
        rel_fol = (rel_fol/3)
    if (frame > 500) and (frame <= 1000):
        rel_fol = (((rel_fol)*2)/3)
    else:
        rel_fol
    return rel_fol

def relevanceScore_fav(frame):
    rel_fav = 0.3
    if frame <= 500:
        rel_fav = (rel_fav/3)
    if (frame > 500) and (frame <= 5000):
        rel_fav = (((rel_fav)*2)/3)
    else:
        rel_fav
    return rel_fav
def relevanceScore_ver(frame):
    rel_ver = 0.1
    if frame == False:
        rel_ver = 0
    else:
        rel_ver
    return rel_ver

def get_dummy(x):
    if x == False:
        x = 0
    elif x == True:
        x = 1
    elif x == 'positive':
        x = 1
    elif x == 'negative':
        x = -1
    elif x == 'neutral':
        x = 0
    return x

for x in df_test['verified']:
    df_test['verified_numerical'][m] = get_dummy(x)
    m = m+1

for x in df_test['sentiment']:
    df_test['sentiment_numerical'][n] = get_dummy(x)
    n = n+1

for x in df_test['RT_count']:
    df_test['Rel_score_rt'][i] = relevanceScore_rt(x)
    i=i+1

for x in df_test['user_followers_cnt']:
    df_test['Rel_score_fol'][j] = relevanceScore_fol(x)
    j=j+1

for x in df_test['fav_count']:
    df_test['Rel_score_fav'][k] = relevanceScore_fav(x)
    k=k+1

for x in df_test['verified']:
    df_test['Rel_score_ver'][l] = relevanceScore_ver(x)
    l=l+1

df_test['Rel_Score'] = df_test['Rel_score_rt'] + df_test['Rel_score_fol'] + df_test['Rel_score_fav'] + df_test['Rel_score_ver']
df_test.drop(df_test.columns[[1, 3, 4, 5, 6, 8, 9, 10, 11, 13]], axis=1, inplace=True)

#df.columns
df_test.to_csv("/test.csv", encoding='utf-8', header=False)