# bin/bash

sudo wget https://s3.amazonaws.com/bigdataanalyticscourse/Json_input_train/final3.json

sudo python /relevancescore_test.py